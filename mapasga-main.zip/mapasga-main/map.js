const tilesProvider = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';

let myMap = L.map('myMap').setView([-3.583610, -38.982069], 12);

L.tileLayer( tilesProvider, {
    maxZoom: 18
}).addTo(myMap)

var mapasga = {
    "type": "Feature",
    "properties": {
        "name": "Coors Field",
        "amenity": "Baseball Stadium",
        "popupContent": "This is where the Rockies play!"
    },
    "geometry": {
        "type": "Polygon",
        "coordinates": [[[-38.8335433557, -3.5457851162], [-38.8184530222, -3.5458579738], [-38.8118667665, -3.5407820180], [-38.8056452180, -3.5475604495], [-38.8256999809, -3.5651252253], [-38.8272435560, -3.5664788430], [-38.8317359514, -3.5704135081], [-38.8534087017, -3.6197114913], [-38.8608911816, -3.6367394136], [-38.8824946048, -3.6859185760], [-38.9089195809, -3.6718186632], [-38.9196091902, -3.6661136148], [-38.9235262419, -3.6722037706], [-38.9222093970, -3.6831330832], [-38.9313641954, -3.6811573929], [-38.9405355320, -3.6842913194], [-38.9609039882, -3.7111660740], [-39.0009490011, -3.6858881807], [-39.0024376734, -3.6857542445], [-39.1435902704, -3.7040113049], [-39.1559718283, -3.7020760327], [-39.1842805135, -3.6976501433], [-39.2139112601, -3.6930152190], [-39.2258637643, -3.6814253201], [-39.2248719253, -3.6711896622], [-39.2245974225, -3.6705419305], [-39.2272546418, -3.6639657041], [-39.2205327870, -3.6422488405], [-39.2240039458, -3.6196155207], [-39.2179219687, -3.6119020017], [-39.2188191226, -3.6072388809], [-39.2231553155, -3.6060985755], [-39.2240965130, -3.6058508421], [-39.2301020093, -3.6030509707], [-39.2381095559, -3.5912657957], [-39.2522498883, -3.5878478387], [-39.2666106090, -3.5829427285], [-39.3150650896, -3.5803550172], [-39.3136161969, -3.5720291457], [-39.3062101610, -3.5650679763], [-39.3096708020, -3.5598751596], [-39.3118503252, -3.5572453630], [-39.3078809675, -3.5414516032], [-39.3095523300, -3.5278034235], [-39.2987277112, -3.5362437787], [-39.2915573243, -3.5285777019], [-39.2865244672, -3.5242822212], [-39.2839441915, -3.5142139598], [-39.2143336288, -3.5140480864], [-39.1656884324, -3.5139288169], [-39.1653413212, -3.5212028305], [-39.1694662659, -3.5282792120], [-39.1331564109, -3.5283820874], [-39.1188771348, -3.5284219201], [-39.1133789301, -3.5284379613], [-39.0752588482, -3.5285428220], [-39.0489173651, -3.5286157499], [-39.0638559184, -3.5371412609], [-39.0988302423, -3.5324701525], [-39.1080951801, -3.5376060858], [-39.1075501512, -3.5428683227], [-39.0943160332, -3.5465158328], [-39.0899243828, -3.5563824792], [-39.0850087171, -3.5509529067], [-39.0694218857, -3.5444214750], [-39.0567334226, -3.5457437133], [-39.0375721039, -3.5503957482], [-39.0257814178, -3.5551259668], [-39.0076413441, -3.5513783333], [-38.9965627660, -3.5546209212], [-38.9877916212, -3.5616391149], [-38.9740435066, -3.5526742949], [-38.9620497719, -3.5483322097], [-38.9615058575, -3.5478017011], [-38.9589384870, -3.5412752193], [-38.9610133511, -3.5351601992], [-38.9644825425, -3.5319301418], [-38.9627689188, -3.5249660450], [-38.9687657915, -3.5191901468], [-38.9689915469, -3.5111215043], [-38.9612858142, -3.5090813778], [-38.9538580635, -3.4981251838], [-38.9531877564, -3.4978332551], [-38.9450858027, -3.4893998077], [-38.9389239435, -3.4830328892], [-38.9383051499, -3.4710841312], [-38.9325287690, -3.4709581069], [-38.9317542833, -3.4649837233], [-38.9209486138, -3.4895971382], [-38.9103653200, -3.5033052818], [-38.8909161470, -3.5047753074], [-38.8685453616, -3.5238627067], [-38.8532297935, -3.5385715231], [-38.8335433557, -3.5457851162]]]
    }
}
L.geoJSON(mapasga).addTo(myMap)

let iconMarker = L.icon({
    iconUrl: 'https://lh3.googleusercontent.com/XeGoTLbapGNz8Nr7zHpT6aVZ6evoP3G4i1sMpFRD_kDkr9MFq5xHDN-CfmMHuuqqAec7bHoiYZ_vcePfEIV9SLWSD4BpNV1IIvsrm1YOhaSeS4pJl0HNeR5Z3D0XCBlnavx-IIMKbFDp6hEr5nKrrGyGJvOFab8CJCeNshROltpRFi0w-XTg22n6kh5uVq1KLj982N5yxvBOmId6uuBW1yWm8xnEb8KLNLp6kt8a4MgSqXisjbSUTcZLGYWDSifly_7eUzoqKnZrxVeUb2Rs_yzt7t0iiuWZLAJLwUzG6l3iF506fiM1gLt_u9uTL0g9p_aTYZsL1T8NF_x9bw1E4_1CKzgJxhvO_2MZqOKHueuRSpvmlXTcS8adl5ALrzkHa9FWMA65xPqkc8SoNxonfs6vJ2nSS65pHmsACLnE1iTXk6ADdD9_xgJpo3-zHB-XJaRhdEXIKps_l-HsVYtntojd1OLPasDvkRHs3q2hCuZafoQfPrWT1V11N3-fTiTM6iT_IHwbCM_4P6eN4fRthINDSm8nx0ma0MG9mnvpIUmiA4S2pUrtfRJIm354T8avhd7aB6C1cScuTOnrbUSdntOHsaezHmGzHn28A0DCADnBIWOXkQ0lFEYiONc8gRVEKAtCSbNml_eE1xvF_CvK8Vgl3yiWVWZN6SXTsHNydAJ6nJbi3KfxeQjh5TBPixLCCks4oJOuNjHeglsteNmtYeg=s220-no?authuser=0',
    iconSize: [70, 70],
    iconAnchor: [30, 60]
})

let marker1 = L.marker([-3.583610, -38.982069], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")

let marker2 = L.marker([-3.604162, -38.986661], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")

let marker3 = L.marker([-3.551664, -38.881054], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")

let marker4 = L.marker([-3.531369, -38.957973], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")

let marker5 = L.marker([-3.670536, -39.112129], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")

let marker6 = L.marker([-3.598164, -39.050642], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")

let marker7 = L.marker([-3.562157, -39.167394], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")

let marker8 = L.marker([-3.559708, -38.827231], {icon: iconMarker, title: "Rede pública", opacity: 0.7})
    .addTo(myMap)
    .bindPopup("<h2> Marcador </h2> <p> Endereço </p>")
